# 준비과정 :
# test할 사진을 ./images/test 에 넣는다. 그리고 test할 사진의 수에 따라 train.py의 BATCH_SIZE를 설정합니다.
# train할 사진을 ./images/train에 넣습니다.
# 그러고 돌리면 x_train.npy와 x_test.npy파일이 생성됩니다.
# 여기서 자동으로 resize를 시켜줘서 사진크기는 생각하지 않아도 된다.
import glob
import os
import cv2
import numpy as np

ratio = 0.95
image_size = 128
test_path='./images/test'
train_path='./images/train'
if not os.path.exists(test_path): os.makedirs(test_path)
if not os.path.exists(train_path): os.makedirs(train_path)
train = []
test=[]
train_paths = glob.glob('./images/train/*')
for path in train_paths:
    img = cv2.imread(path)
    img = cv2.resize(img, (image_size, image_size))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    train.append(img)

test_paths = glob.glob('./images/test/*')
for path in test_paths:
    img = cv2.imread(path)
    img = cv2.resize(img, (image_size, image_size))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    test.append(img)

train = np.array(train, dtype=np.uint8)
test = np.array(test, dtype=np.uint8)
#np.random.shuffle(train)
#np.random.shuffle(test)

#p = int(ratio * len(train))
x_train = train
x_test = test

if not os.path.exists('./npy'):
    os.mkdir('./npy')
np.save('./npy/x_train.npy', x_train)
np.save('./npy/x_test.npy', x_test)
